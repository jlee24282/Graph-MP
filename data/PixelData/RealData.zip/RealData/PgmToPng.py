# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 12:40:00 2017

@author: JLee
"""

from PIL import Image
import glob

#img = Image.open('faces/an2i/an2i_left_angry_open_2.pgm')

def pgmTopng():
    for imgDir in glob.glob("faces/an2i/*"):
        try:
            img = Image.open(imgDir)
            imgDir = imgDir.replace('pgm','png')
            imgDir = 'pngFiles/'+ imgDir
        #print imgDir
            img.save(imgDir)
        except:
            pass
    
    
def resultPicture():
    im = Image.open('Results/output_4.png').convert('RGB')         
    pixelMap = im.load()

    resultNodes = [781, 782, 783, 813, 815, 816, 833, 845, 865, 877, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 928, 929, 930]
    
    w=im.size[0]
    h=im.size[1]
    for i in range(w):
        for j in range(h):
            for k in resultNodes:
                if k/h == i and k%w == j:
                    pixelMap[i,j] = (255,0,0)
             
    im.show()       
    im.save("Results/result_4.png") 
    im.close()


def main():    
    resultPicture()
    
    
if __name__ == '__main__':
    main()